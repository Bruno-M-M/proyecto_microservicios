package com.Pago.Metodo_de_pago;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MetodoDePagoApplicationTests {

	@Test
	void contextLoads() {
	}

}
