package com.Carrito.Carrito_compras.Repository;

import com.Carrito.Carrito_compras.Model.Carrito;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CarritoRepository  extends JpaRepository<Carrito,Long> {
    List<Carrito> findByClienteId(Long clienteId);
    List<Carrito>   findByEstado(Carrito.EstadoPedido estado);

    List<Carrito> findbyClienteIdAndEstado(Long clienteId,Carrito.EstadoPedido estado);
}
