package com.Carrito.Carrito_compras.Service;

import com.Carrito.Carrito_compras.DTO.ClienteDTO;
import com.Carrito.Carrito_compras.DTO.ProductoDTO;
import com.Carrito.Carrito_compras.Model.Carrito;
import com.Carrito.Carrito_compras.Repository.CarritoRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Service
@Transactional
public class CarritoService {

    @Autowired
    private CarritoRepository carritoRepository;

    @Autowired
    private RestTemplate restTemplate;



    @Value("${microservisio.clientes.url}")
    private String clientesUrl;

    @Value("${microservicio.inventario.url}")
    private  String inventarioUrl;



    private ClienteDTO obtenerCliente(Long clienteId){
        try {
            String url = clientesUrl + "/" + clienteId;
            return  restTemplate.getForObject(url, ClienteDTO.class);
        } catch ( HttpClientErrorException.NotFound e){
            throw  new RuntimeException("Cliente no encontrado con ID: " + clienteId);

        } catch (Exception e){
            throw new RuntimeException("Error al conectar con el servicio de clientes: " + e.getMessage());
        }
    }


    private ProductoDTO obtenerProducto(Long productoId){
        try{
            String url= inventarioUrl + "/" + productoId;
            return restTemplate.getForObject(url,ProductoDTO.class);
        }catch (HttpClientErrorException.NotFound e){
            throw new RuntimeException("Producto no encontrado con ID: " + productoId);
        } catch (Exception e){
            throw  new RuntimeException(" Error al conectar con el servicio de inventario: " + e.getMessage());
        }
    }


}
