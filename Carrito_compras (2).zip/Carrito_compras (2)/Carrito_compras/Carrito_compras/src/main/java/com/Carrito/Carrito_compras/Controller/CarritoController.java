package com.Carrito.Carrito_compras.Controller;

import com.Carrito.Carrito_compras.DTO.CarritoDetalleDTO;
import com.Carrito.Carrito_compras.Model.Carrito;
import com.Carrito.Carrito_compras.Service.CarritoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/")
public class CarritoController {


    @Autowired
    private CarritoService carritoService;



    @GetMapping
    public ResponseEntity<List<CarritoDetalleDTO>> getTodo(){
        return ResponseEntity.ok(carritoService.ge)
    }
}
