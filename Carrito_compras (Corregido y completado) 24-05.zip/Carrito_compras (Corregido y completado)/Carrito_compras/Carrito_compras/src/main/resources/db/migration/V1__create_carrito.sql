CREATE TABLE IF NOT EXISTS carrito (
                                       id              BIGINT AUTO_INCREMENT PRIMARY KEY,
                                       nombre_producto VARCHAR(255) NOT NULL,
    cliente_id      BIGINT       NOT NULL,
    producto_id     BIGINT       NOT NULL,
    cantidad        INT          NOT NULL DEFAULT 1,
    estado          VARCHAR(20)  NOT NULL DEFAULT 'PENDIENTE',
    fecha_confirmacion DATETIME  NULL,
    CONSTRAINT chk_estado   CHECK (estado IN ('PENDIENTE', 'CONFIRMADO', 'PAGADO', 'CANCELADO')),
    CONSTRAINT chk_cantidad CHECK (cantidad > 0)
    );
