CREATE TABLE clientes(

    id          BIGINT NOT NULL AUTO_INCREMENT,
    run         INTEGER(8) NOT NULL UNIQUE,
    dv          VARCHAR(1) NOT NULL,
    nombre      VARCHAR(100) NOT NULL,
    correo      VARCHAR(100) NOT NULL,
    direccion   VARCHAR(100) NOT NULL,
    telefono    INTEGER(9) NOT NULL,
    contraseña  VARCHAR(100) NOT NULL
    PRIMARY KEY (id)
);