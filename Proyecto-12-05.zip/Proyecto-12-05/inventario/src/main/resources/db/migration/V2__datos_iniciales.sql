INSERT INTO product (nombre, descripcion, precio, stock, categoria)
VALUES("Chocapic", "Cereal sabor chocolate 400gr", 2990, 50, "Despensa"),
VALUES("Nescafe seleccion", "Cafe instantaneo soluble 200gr", 12990, 40, "Despensa"),
VALUES("Poett frescura lavanda", "Limpiapiso con aroma a lavanda 900ml", 1730, 64, "Limpieza"),
VALUES("Leche Colun entera", "Leche colun entera obtenida a partir de leche fresca 1lt", 1380, 85, "Lacteos"),
VALUES("Filetitos de pollo", "Filetitos de pechuga de pollo 700gr", 7490, 36, "Carnes");