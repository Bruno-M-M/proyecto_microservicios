CREATE TABLE IF NOT EXISTS boletas (
                                       id                BIGINT AUTO_INCREMENT PRIMARY KEY,
                                       cliente_id        BIGINT        NOT NULL,
                                       cliente_nombre    VARCHAR(255)  NOT NULL,
    cliente_run       VARCHAR(20)   NOT NULL,
    cliente_correo    VARCHAR(255)  NOT NULL,
    cliente_direccion VARCHAR(255)  NOT NULL,
    cliente_telefono  INT           NOT NULL,
    metodo_pago       VARCHAR(20)   NOT NULL,
    total_neto        DOUBLE        NOT NULL,
    iva               DOUBLE        NOT NULL,
    total_con_iva     DOUBLE        NOT NULL,
    fecha_emision     DATETIME      NOT NULL,
    estado            VARCHAR(20)   NOT NULL DEFAULT 'EMITIDA',
    pedidos_ids       VARCHAR(1000) NOT NULL,
    CONSTRAINT chk_metodo_pago CHECK (metodo_pago IN ('EFECTIVO','DEBITO','CREDITO','TRANSFERENCIA')),
    CONSTRAINT chk_estado_boleta CHECK (estado IN ('EMITIDA','ANULADA'))
);
