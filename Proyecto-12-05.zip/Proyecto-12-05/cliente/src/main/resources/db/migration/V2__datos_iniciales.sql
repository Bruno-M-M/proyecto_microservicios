INSERT INTO clientes (run, dv, nombre, correo, direccion, telefono, contraseña)
VALUES (206888807, "5", "Bruno Mateluna", "br.mateluna@duocuc.cl", "Calle quinta vergara 666", 949000000, passwordEncoder.encode("abc123."),
VALUES (12345678, "9", "Claudio Bravo", "cl.bravo@chile.cl", "Av.santiago 522", 967342652, passwordEncoder.encode("chile1234");