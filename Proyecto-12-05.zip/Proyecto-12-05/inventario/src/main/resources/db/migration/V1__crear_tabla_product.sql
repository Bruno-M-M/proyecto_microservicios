CREATE TABLE product(

    id              BIGINT NOT NULL AUTO_INCREMENT,
    nombre          VARCHAR(100) NOT NULL,
    descripcion     VARCHAR(300) NOT NULL,
    precio          INTEGER(10) NOT NULL,
    stock           INTEGER(4) NOT NULL,
    categoria       VARCHAR(50) NOT NULL
    PRIMARY KEY (id)
);