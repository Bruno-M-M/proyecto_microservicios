package com.Carrito.Carrito_compras.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Table(name = "carrito")
@AllArgsConstructor
@NoArgsConstructor
public class Carrito {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
     private Long id;

    @Column(nullable = false)
    private String nombre_producto;


    @Column(nullable = false)
    private Long clienteId;


    @Column(nullable = false)
    private Long productoId;

    @Column
    private Integer cantidad;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private EstadoPedido estado = EstadoPedido.PENDIENTE;

    public enum EstadoPedido{
        PENDIENTE, CONFIRMADO, CANCELADO
    }
}
